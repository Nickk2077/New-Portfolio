'use client'

import dynamic from 'next/dynamic'
import Loader from '@/components/ui/Loader'
import Navigation from '@/components/layout/Navigation'
import SmoothScroll from '@/components/layout/SmoothScroll'
import Hero from '@/components/sections/Hero'
import MarqueeBand from '@/components/ui/MarqueeBand'
import Footer from '@/components/layout/Footer'

// Dynamic imports for heavy components
const CustomCursor = dynamic(() => import('@/components/ui/CustomCursor'), { ssr: false })
const FloatingParticles = dynamic(() => import('@/components/ui/FloatingParticles'), { ssr: false })
const About = dynamic(() => import('@/components/sections/About'))
const Services = dynamic(() => import('@/components/sections/Services'))
const Projects = dynamic(() => import('@/components/sections/Projects'))
const Reel = dynamic(() => import('@/components/sections/Reel'))
const UIUXCaseStudies = dynamic(() => import('@/components/sections/UIUXCaseStudies'))
const Gallery3D = dynamic(() => import('@/components/sections/Gallery3D'))
const Contact = dynamic(() => import('@/components/sections/Contact'))

export default function Home() {
  return (
    <SmoothScroll>
      {/* Loader overlay */}
      <Loader />

      {/* Custom cursor (desktop only) */}
      <CustomCursor />

      {/* Ambient particle field */}
      <FloatingParticles />

      {/* Navigation */}
      <Navigation />

      {/* Main content */}
      <main>
        {/* 1. Hero — fullscreen 3D intro */}
        <Hero />

        {/* Marquee band */}
        <MarqueeBand />

        {/* 2. About */}
        <About />

        {/* 3. Services */}
        <Services />

        {/* 4. Featured Projects */}
        <Projects />

        {/* 5. Motion Reel */}
        <Reel />

        {/* 6. UI/UX Case Studies */}
        <UIUXCaseStudies />

        {/* 7. 3D Gallery */}
        <Gallery3D />

        {/* 8. Contact */}
        <Contact />
      </main>

      {/* Footer */}
      <Footer />
    </SmoothScroll>
  )
}
