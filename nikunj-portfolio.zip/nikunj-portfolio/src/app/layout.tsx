import type { Metadata, Viewport } from 'next'
import '../styles/globals.css'

export const metadata: Metadata = {
  title: 'Nikunj Zapadiya — Creative Designer & Motion Artist',
  description: 'Portfolio of Nikunj Zapadiya, a multidisciplinary creative specializing in Graphic Design, Motion Graphics, Video Editing, UI/UX Design, and 3D Art.',
  keywords: ['Nikunj Zapadiya', 'Graphic Designer', 'Motion Graphics', 'Video Editor', 'UI/UX Designer', '3D Artist', 'Creative Portfolio'],
  authors: [{ name: 'Nikunj Zapadiya' }],
  creator: 'Nikunj Zapadiya',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://nikunjzapadiya.com',
    title: 'Nikunj Zapadiya — Creative Designer & Motion Artist',
    description: 'Multidisciplinary creative pushing the boundaries of design and motion.',
    siteName: 'Nikunj Zapadiya Portfolio',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Nikunj Zapadiya — Creative Designer & Motion Artist',
    description: 'Multidisciplinary creative pushing the boundaries of design and motion.',
    creator: '@nikunjzapadiya',
  },
  robots: {
    index: true,
    follow: true,
  },
}

export const viewport: Viewport = {
  themeColor: '#030305',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body>
        {children}
      </body>
    </html>
  )
}
